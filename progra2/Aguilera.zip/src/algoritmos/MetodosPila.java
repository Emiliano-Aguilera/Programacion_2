package algoritmos;

public class MetodosPila {
    public void PasarPila() {
         
    }
}
