package impl.Parcial;

public class PilaColaPares {
    
}
