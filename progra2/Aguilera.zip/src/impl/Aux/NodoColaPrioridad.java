package impl.Aux;

public class NodoColaPrioridad {
    public int valor;
    public int prioridad;
    public NodoColaPrioridad siguiente;
}
