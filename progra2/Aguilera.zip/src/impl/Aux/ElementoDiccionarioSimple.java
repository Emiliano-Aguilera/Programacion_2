package impl.Aux;

public class ElementoDiccionarioSimple {
    public int clave;
    public int valor;

    public void InicializarElemento( int _clave, int _valor ) {
        clave = _clave;
        valor = _valor;
    }
}
