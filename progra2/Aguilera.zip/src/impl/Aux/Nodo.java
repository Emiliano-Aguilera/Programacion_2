package impl.Aux;

public class Nodo {
    public int info;
    public Nodo sig;
}
