package impl.Aux;

public class NodoDiccionarioSimple {
    public int clave;
    public int valor;
    public NodoDiccionarioSimple sig;
}
