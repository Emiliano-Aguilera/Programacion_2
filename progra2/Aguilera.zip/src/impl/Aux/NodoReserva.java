package impl.Aux;

public class NodoReserva {
    public int id_reserva;
    public int id_pasajero;
    public int nro_vuelo;
    public int nro_asiento;
    public int fecha;
    public NodoReserva sig;
}
