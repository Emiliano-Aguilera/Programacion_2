package impl.Guia;

import api.ConjuntoTDA;

public class ConjuntoLD implements ConjuntoTDA{
    public void InicializarConjunto() {

    }
    
    public int Elegir() {

    }

    public boolean ConjuntoVacio() {

    }

    public boolean Pertenece(int elemento) {

    }

    public void Sacar(int elemento) {

    }

    public void Agregar(int elemento) {

    }

    public void MostrarConjunto() {

    }

}
