package api;

public interface PilaColaParesTDA {
    void Inicializar();
    int Mostrar();
    void Cargar(int elemento);
    void Quitar(int elemento);
    Boolean EstaVacia();
    void Imprimir();
}
