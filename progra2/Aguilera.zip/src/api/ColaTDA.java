package api;

public interface ColaTDA {
    int Primero();
    boolean ColaVacia();
    void Desacolar();
    void Acolar(int elemento);
    void InicializarCola();
}
